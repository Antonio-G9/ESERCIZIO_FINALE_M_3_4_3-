-- CREAZIONE SCHEMA  Esercizio_finale_M_3_4_3_FINALE
create schema Esercizio_finale_M_3_4_3_FINALE


-- CREAZIONE TABELLA product
CREATE TABLE IF NOT EXISTS product (
    product_id INT NOT NULL,
    product_name VARCHAR(255),
    product_category VARCHAR(255),
    product_price DECIMAL(10 , 2 ),
    PRIMARY KEY (product_id)
);
  
  
  -- CREAZIONE TABELLA region 
  CREATE TABLE IF NOT EXISTS region (
    region_id INT NOT NULL,
    region_name VARCHAR(255),
    PRIMARY KEY (region_id)
);
    
    
	-- CREAZIONE TABELLA sales
    CREATE TABLE IF NOT EXISTS sales (
    sales_id INT NOT NULL AUTO_INCREMENT,
    region_id INT NOT NULL,
    product_id INT NOT NULL,
    sales_date DATETIME,
    sales_qty INT NOT NULL,
    sales_amount DECIMAL(10 , 2 ),
    PRIMARY KEY (sales_id),
    FOREIGN KEY (region_id)
        REFERENCES region (region_id),
    FOREIGN KEY (product_id)
        REFERENCES product (product_id)
);
-- --------------------------------------------------------------

-- INSERIMENTO DATI TABELLA product
insert into product (product_id, product_name, product_category, product_price)
values
(1,'LEGO','Costruzioni',10),
(2,'RISIKO','Giochi_da_tavolo',20),
(3,'MONOPOLY','Giochi_da_tavolo',15),
(4,'D&D','Giochi_da_tavolo',50),
(5,'DRONI','Tecnologici',120),
(6,'LEGO City	','Costruzioni',35),
(7,'NERF','Giochi_di_lancio',15),
(8,'FUNKO POP','Collezione',20),
(9,'RC CARS ','Veicoli_radiocomandati',40),
(10,'ONE PIECE','Collezione',80),
(11,'POKEMON','Collezione',10);


-- INSERIMENTO DATI TABELLA region
insert into region (region_id, region_name)
values 
(1,'Belgio'),
(2,'Paesi Bassi'),
(3,'Francia'),
(4,'Danimarca'),
(5,'Italia'),
(6,'Norvegia'),
(7,'Spagna'),
(8,'Svizzera'),
(9,'Germania'),
(10,'Regno Unito');


-- INSERIMENTO DATI TABELLA sales

insert into sales (region_id, product_id, sales_date, sales_qty, sales_amount)
values
(1,7,'2022-01-28',24,360),
(2,9,'2022-01-28',10,400),
(3,10,'2022-01-28',5,400),
(8,4,'2022-02-28',5,250),
(4,4,'2022-02-28',4,200),
(6,6,'2022-02-28',10,350),
(5,3,'2022-02-28',20,300),
(10,2,'2022-02-28',26,520),
(6,3,'2022-03-28',16,240),
(6,3,'2022-03-28',29,435),
(9,1,'2022-03-28',45,450),
(7,6,'2022-03-28',36,1260),
(4,7,'2022-03-28',47,705),
(2,9,'2022-03-28',6,240),
(4,8,'2022-03-28',9,180),
(6,8,'2022-04-28',17,340),
(2,4,'2022-04-28',21,1050),
(1,1,'2022-04-28',60,600),
(1,10,'2022-04-28',12,960),
(1,10,'2022-04-28',7,560),
(3,2,'2022-05-28',9,180),
(5,6,'2022-05-28',4,140),
(10,6,'2022-05-28',14,490),
(6,9,'2022-05-28',9,360),
(8,4,'2022-05-28',20,1000),
(9,10,'2022-05-28',3,240),
(9,3,'2022-05-28',39,585),
(6,3,'2022-05-28',25,375),
(4,8,'2022-05-28',6,120),
(4,9,'2022-05-28',9,360),
(4,4,'2022-05-28',7,350),
(4,4,'2022-05-28',20,1000),
(4,6,'2022-05-28',6,210),
(4,3,'2022-06-28',7,105),
(5,3,'2022-06-28',15,225),
(10,3,'2022-06-28',9,135),
(5,3,'2022-06-28',50,750),
(2,3,'2022-07-28',50,750),
(2,10,'2022-07-28',9,720),
(6,10,'2022-07-28',7,560),
(8,10,'2022-08-28',6,480),
(4,10,'2022-08-28',12,960),
(2,6,'2022-08-28',14,490),
(6,9,'2022-09-28',16,640),
(4,9,'2022-09-28',54,2160),
(1,7,'2022-09-28',26,390),
(1,4,'2022-10-28',17,850),
(2,10,'2022-10-28',6,480),
(9,2,'2022-11-28',9,180),
(9,2,'2022-11-28',10,200),
(10,6,'2022-11-28',20,700),
(4,2,'2022-11-28',15,300),
(4,2,'2022-12-28',30,600),
(7,4,'2022-12-28',38,1900),
(2,7,'2022-12-28',24,360),
(6,6,'2022-12-28',29,1015),
(2,2,'2022-12-28',70,1400),
(8,4,'2022-12-28',5,250),
(4,4,'2022-12-28',4,200),
(6,6,'2022-12-28',10,350),
(5,3,'2022-12-28',20,300),
(10,2,'2022-12-28',26,520),
(6,3,'2022-12-28',16,240),
(6,3,'2022-12-28',29,435),
(2,4,'2022-12-28',21,1050),
(1,1,'2022-12-28',60,600),
(1,10,'2022-12-28',12,960),
(2,9,'2022-12-28',10,400),
(3,10,'2022-12-28',5,400),
(8,4,'2022-12-28',5,250),
(4,4,'2022-12-28',4,200),
(6,6,'2022-12-28',10,350),
(5,3,'2023-01-28',20,300),
(4,8,'2023-01-28',6,120),
(4,9,'2023-01-28',9,360),
(4,4,'2023-01-28',7,350),
(4,4,'2023-01-28',20,1000),
(4,6,'2023-02-28',6,210),
(4,3,'2023-02-28',7,105),
(5,3,'2023-02-28',15,225),
(10,3,'2023-02-28',9,135),
(5,3,'2023-02-28',50,750),
(6,9,'2023-03-28',16,640),
(4,9,'2023-03-28',54,2160),
(1,7,'2023-03-28',26,390),
(1,4,'2023-03-28',17,850),
(2,10,'2023-03-28',6,480),
(9,2,'2023-04-28',9,180),
(10,2,'2023-04-28',26,520),
(6,3,'2023-04-28',16,240),
(6,3,'2023-04-28',29,435),
(9,1,'2023-05-28',45,450),
(7,6,'2023-05-28',36,1260),
(2,2,'2023-05-28',70,1400),
(8,4,'2023-05-28',5,250),
(4,4,'2023-06-28',4,200),
(6,6,'2023-06-28',10,350),
(5,3,'2023-06-28',20,300),
(10,2,'2023-06-28',26,520),
(6,3,'2023-06-28',16,240),
(2,9,'2023-07-28',10,400),
(3,10,'2023-07-28',5,400),
(8,4,'2023-07-28',5,250),
(4,4,'2023-08-28',4,200),
(6,6,'2023-08-28',10,350),
(5,3,'2023-09-28',20,300),
(4,8,'2023-09-28',6,120),
(4,9,'2023-09-28',9,360),
(4,4,'2023-09-28',7,350),
(4,4,'2023-10-28',20,1000),
(4,6,'2023-10-28',6,210),
(4,3,'2023-10-28',7,105),
(5,3,'2023-11-28',15,225),
(10,3,'2023-11-28',9,135),
(5,3,'2023-11-28',50,750),
(6,9,'2023-12-28',16,640),
(4,9,'2023-12-28',54,2160),
(1,7,'2023-12-28',26,390),
(1,4,'2023-12-28',17,850),
(2,10,'2023-12-28',6,480),
(9,2,'2023-12-28',9,180),
(10,2,'2023-12-28',26,520),
(6,3,'2023-12-28',16,240),
(6,3,'2023-12-28',29,435),
(4,4,'2023-12-28',20,1000),
(4,6,'2023-12-28',6,210),
(4,3,'2023-12-28',7,105),
(5,3,'2023-12-28',15,225),
(10,3,'2023-12-28',9,135),
(5,3,'2023-12-28',50,750),
(2,3,'2023-12-28',50,750),
(2,10,'2023-12-28',9,720),
(6,10,'2023-12-28',7,560),
(8,10,'2023-12-28',6,480),
(4,10,'2023-12-28',12,960),
(2,6,'2024-01-28',14,490),
(6,9,'2024-01-28',16,640),
(4,9,'2024-01-28',54,2160);

-- -----------------------------------------------------------

-- PUNTO #1 Verificare che i campi definiti come PK siano univoci.

-- RESTITUISCE I CAMPI DEFINITI NELLA TABELLA product
show columns from product;

-- RESTITUISCE I CAMPI DEFINITI NELLA TABELLA region
show columns from region;

-- RESTITUISCE I CAMPI DEFINITI NELLA TABELLA sales
show columns from sales;


-- PUNTO #2 Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.
SELECT DISTINCT
    sa.product_id,
    pr.product_name,
    YEAR(sa.sales_date) AS year_sales,
    SUM(sa.sales_amount) AS total_amount
FROM
    sales AS sa
        INNER JOIN
    product AS pr ON pr.product_id = sa.product_id
GROUP BY sa.product_id , YEAR(sa.sales_date);


-- PUNTO #3 Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.
SELECT DISTINCT
    sa.region_id,
    re.region_name,
    YEAR(sa.sales_date) AS year_sales,
    SUM(sa.sales_amount) AS total_amount
FROM
    sales AS sa
        INNER JOIN
    region AS re ON re.region_id = sa.region_id
GROUP BY sa.region_id , YEAR(sa.sales_date)
ORDER BY YEAR(sa.sales_date) , re.region_name DESC;


-- PUNTO #4 Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?
select  pr.product_category, sum(sa.sales_qty) as total_sales_qty from sales as sa 
inner join product as pr on pr.product_id=sa.product_id
group by pr.product_category
order by total_sales_qty desc 
limit 1 ;


-- PUNTO #5 Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci Risolutivi differenti.

-- METODO #1
SELECT 
    pr.product_id,
    pr.product_name,
    pr.product_category,
    pr.product_price,
    sa.sales_id
FROM
    product AS pr
        LEFT JOIN
    sales AS sa ON pr.product_id = sa.product_id
WHERE
    sa.sales_id IS NULL;
    
-- METODO #2
    
SELECT 
    *
FROM
    product AS pr
WHERE
    pr.product_id NOT IN (SELECT 
            sa.product_id
        FROM
            sales AS sa);
            
            
-- PUNTO #6            
SELECT 
    pr.product_id,
    pr.product_name,
    MAX(sa.sales_date) AS last_sales
FROM
    sales AS sa
        INNER JOIN
    product AS pr ON pr.product_id = sa.product_id
GROUP BY pr.product_id , pr.product_name;     